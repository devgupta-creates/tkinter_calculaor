from tkinter import *

window = Tk()
window.geometry("500x500")

def click(num):
    result = e.get()
    e.delete(0, END)
    e.insert(0, str(result) + str(num))

e = Entry(window, width=50, borderwidth=5)
e.place(x=0, y=0)

# Number buttons
Button(window, text="1", width=10, command=lambda: click(1)).place(x=0, y=60)
Button(window, text="2", width=10, command=lambda: click(2)).place(x=120, y=60)
Button(window, text="3", width=10, command=lambda: click(3)).place(x=240, y=60)
Button(window, text="4", width=10, command=lambda: click(4)).place(x=0, y=120)
Button(window, text="5", width=10, command=lambda: click(5)).place(x=120, y=120)
Button(window, text="6", width=10, command=lambda: click(6)).place(x=240, y=120)
Button(window, text="7", width=10, command=lambda: click(7)).place(x=0, y=180)
Button(window, text="8", width=10, command=lambda: click(8)).place(x=120, y=180)
Button(window, text="9", width=10, command=lambda: click(9)).place(x=240, y=180)
Button(window, text="0", width=10, command=lambda: click(0)).place(x=120, y=240)

# Functions for operations
def add():
    global f_num, math
    f_num = int(e.get())
    math = "addition"
    e.delete(0, END)

def subtract():
    global f_num, math
    f_num = int(e.get())
    math = "subtraction"
    e.delete(0, END)

def mult():
    global f_num, math
    f_num = int(e.get())
    math = "multiplication"
    e.delete(0, END)

def divi():
    global f_num, math
    f_num = int(e.get())
    math = "division"
    e.delete(0, END)
def power():
    first_number = e.get()
    global f_num, math 
    math = "power"
    f_num = int(first_number)
    e.delete(0, END)
def sqrt():
    first_number = e.get()
    global f_num, math 
    math = "sqrt"
    f_num = int(first_number)
    e.delete(0, END)
    

# Operation buttons
Button(window, text="+", width=12, command=add).place(x=360, y=60)
Button(window, text="-", width=12, command=subtract).place(x=360, y=120)
Button(window, text="X", width=12, command=mult).place(x=360, y=180)
Button(window, text="%", width=12, command=divi).place(x=360, y=240)
Button(window, text="power", width=12 , command= power).place(x=120, y=300)
Button(window, text="sqrt", width=12 , command= sqrt ).place(x=240, y=300)
# Clear button
Button(window, text="clear", width=12, command=lambda: e.delete(0, END)).place(x=240, y=240)

# Equal button
def equal():
    second_number = e.get()
    e.delete(0, END)
    if math == "addition":
        e.insert(0, f_num + int(second_number))
    elif math == "subtraction":
        e.insert(0, f_num - int(second_number))
    elif math == "multiplication":
        e.insert(0, f_num * int(second_number))
    elif math == "division":
        e.insert(0, f_num / int(second_number))
    elif math == "power":
        e.insert(0, f_num ** int(second_number))
    elif math == "sqrt":
        e.insert(0, f_num ** 0.5)
Button(window, text="=", width=12, command=equal).place(x=0, y=240)

mainloop()